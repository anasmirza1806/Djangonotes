from django.shortcuts import render
from .models import Article
# Create your views here.
def index(request):
    return render(request,'index.html')

def article_list(request):
    articles = Article.objects.all()

    return render(request,'article_list.html',{'articles':articles})