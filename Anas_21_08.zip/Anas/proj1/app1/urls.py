from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    # path('article_list/',views.article_list,name='article_list'),
    path('register',views.registration_view, name='register'),
    path('login', views.login_view, name='login'),

]
