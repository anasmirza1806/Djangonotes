from django.shortcuts import render
from .forms import RegistrationForm,LoginForm
# from .models import Article
# Create your views here.
def home(request):
    return render(request,'home.html')

# def article_list(request):
#     articles = Article.objects.all()
#
#     return render(request,'article_list.html',{'articles':articles})

def registration_view(request):
    return render(request,'register.html')

def login_view(request):
    return render(request,'login.html')